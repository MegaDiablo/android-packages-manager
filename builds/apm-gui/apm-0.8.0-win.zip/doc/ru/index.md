Содержание
==========

- [Введение](introduce.md#introduce)
- [Управление](control.md#control)
 -- [Установка](control.md#control.install)
  --- [Меню](control.md#control.install.menu)
  --- [Drag&Drop](control.md#control.install.d&d)